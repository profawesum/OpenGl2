#pragma once

#include <glew.h>
#include <freeglut.h>


class LoadTexture {

public:

	GLuint loadTexture(const char *path);
private:

};