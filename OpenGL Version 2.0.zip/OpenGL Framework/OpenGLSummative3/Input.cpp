#include <iostream>
#include <freeglut.h>
#include <vector>
#include "Input.h"
#include "PlayerManager.h"
#include "glm.hpp"

using namespace std;

enum InputState
{
	INPUT_UP,
	INPUT_DOWN,
	INPUT_UP_FIRST,
	INPUT_DOWN_FIRST,
};

InputState KeyState[255];

Input::Input()
{
}

Input::~Input()
{
}

//checks to see if there is a key being pushed
bool Input::CheckKeyDown(int key)
{
	if (KeyState[key] == INPUT_DOWN)
	{
		return(true);
	}
	return(false);
}

//sets a key to being down
void Input::KeyboardDown(unsigned char key, int x, int y)
{
	KeyState[key] = INPUT_DOWN;
}


//sets a key to being up
void Input::KeyboardUp(unsigned char key, int x, int y)
{
	KeyState[key] = INPUT_UP;
}

